package com.revature.dto;

public class ExceptionMessageDTO {

	private String message;
	
	public ExceptionMessageDTO() {
		super();
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
