package com.revature.model;

public interface CalculableArea {

	public void calculateArea();
	public double getArea();
	
}
