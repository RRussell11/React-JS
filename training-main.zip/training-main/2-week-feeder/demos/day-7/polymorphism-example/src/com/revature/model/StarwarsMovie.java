package com.revature.model;

public class StarwarsMovie extends Movie {

	@Override
	public String getMovieDescription() {
		return "In a galaxy far far away... lasers";
	}
	
}
