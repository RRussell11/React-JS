# Graded Requirements
- Existance of Four Rooms or More, With Descriptions, created from Room class base template. ~ 20pt
- Choice of Four Directions (with Functionality to Move) ~ 20 pts
- Encapsulated Variables and Use of Getters/Setters ~ 10 pts
- Use of Abstraction ~ 4 pts
- Additional Features and Actions ~ 5-10 bonus pts
- Presentation ~ 10 pts
    - demo of the application
    - speaking to issues/over coming errors/ distractions
    - speak to the application of the 4 pillars of OOP
    - keeping to time
    - answering questions
- Validation ~ 5pts
- Acceptance of multi-word commands ~ 4pts
- Clear understanding of inheritance ~ 5pts 
- Use of core structure or logical deviation ~ 5pts 
- Use of a Collection (s)/ Map ~ 5pts 
 
