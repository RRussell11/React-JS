package com.revature;

import com.revature.list.ListDemo;
import com.revature.map.MapDemo;
import com.revature.queue.QueueDemo;
import com.revature.set.SetDemo;

public class Application {

	public static void main(String[] args) {
//		ListDemo.demo();
		
//		QueueDemo.demo();
		
//		SetDemo.demo();
		
		MapDemo.demo();
	}

}
