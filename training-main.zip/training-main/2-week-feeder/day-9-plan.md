# Day 9 Plan

1. Take attendance (19 associates)
2. Put associates into breakout rooms to talk for 20 minutes
3. Go back to the idea of iterators
    - ArrayList example https://github.com/revature-bach/210208-roc/blob/main/demos/week-4-demos/MyArrayList/src/com/revature/MyArrayList.java
4. Talk about maps
5. Comparable v. Comparator
6. Study guide
7. Revisit the idea of lambdas
8. Have associates work on project B
    - Presentation on Friday

Any concerns about associate count, deal w/ Aron or Steve
- Bring up with Fred about concerns w/ client target