package com.revature;

public class Math {

	public boolean isOdd(int num) {
		return num % 2 == 1;
	}
	
	public boolean isEven(int num) {
		return num % 2 == 0;
	}
	
}
