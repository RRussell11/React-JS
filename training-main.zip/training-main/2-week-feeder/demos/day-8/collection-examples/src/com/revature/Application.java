package com.revature;

import com.revature.list.ListDemo;
import com.revature.queue.QueueDemo;

public class Application {

	public static void main(String[] args) {
//		ListDemo.demo();
		
		QueueDemo.demo();
	}

}
