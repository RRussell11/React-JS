package com.revature.model;

public class JawsMovie extends Movie {

	@Override
	public String getMovieDescription() {
		return "A movie about man-eating sharks";
	}
	
}
