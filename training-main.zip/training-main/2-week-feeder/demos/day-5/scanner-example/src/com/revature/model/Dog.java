package com.revature.model;

public class Dog {

	public String name;
	public double weight;
	public String breed;
	
	public Dog(String name, double weight, String breed) {
		this.name = name;
		this.weight = weight;
		this.breed = breed;
	}
	
}
