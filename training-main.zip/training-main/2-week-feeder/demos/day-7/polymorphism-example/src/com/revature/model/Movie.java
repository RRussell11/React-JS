package com.revature.model;

public class Movie {

	public String getMovieDescription() {
		return "GENERIC MOVIE DESCRIPTION";
	}
	
}
